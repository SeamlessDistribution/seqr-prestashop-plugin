<?php
$_seqr_dir=dirname(__FILE__);
require_once($_seqr_dir . '/PsConfig.php');
require_once($_seqr_dir . '/PsFactory.php');
require_once($_seqr_dir . '/PsSeqrService.php');
require_once($_seqr_dir . '/PsSeqrFrontController.php');


